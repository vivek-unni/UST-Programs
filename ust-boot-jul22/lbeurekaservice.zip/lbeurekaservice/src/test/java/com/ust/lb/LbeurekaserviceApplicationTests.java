package com.ust.lb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LbeurekaserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
